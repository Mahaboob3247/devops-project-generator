public class App {
public static void main(String[] args){
System.out.println("Java DevOps App Running");
}
}